def hello_world_python(request):
    return f"Hello, World!"